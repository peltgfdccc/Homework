package com.example.springboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.springboot.entity.Record;
import com.example.springboot.entity.Repair;
import com.example.springboot.mapper.RecordMapper;
import org.springframework.stereotype.Service;


public interface RecordService extends IService<Record>  {

    int addRecord(Record record);
    int deleteRecord(Integer id);

    Page find(Integer pageNum, Integer pageSize, String search);
}
