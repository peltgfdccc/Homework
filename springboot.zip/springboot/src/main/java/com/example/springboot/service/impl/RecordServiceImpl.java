package com.example.springboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.springboot.entity.Record;
import com.example.springboot.entity.Repair;
import com.example.springboot.entity.Visitor;
import com.example.springboot.mapper.RecordMapper;
import com.example.springboot.service.RecordService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;


@Service
public class RecordServiceImpl extends ServiceImpl<RecordMapper, Record> implements RecordService {

    /**
     * 注入DAO层对象
     */
    @Resource
    private RecordMapper recordMapper;


    @Override
    public int addRecord(Record record) {
        Record record1 = new Record();
        record1.setGoDate(record.getGoDate());
        record1.setStudentName(record.getStudentName());
        record1.setType(record.getType());
        int insert = recordMapper.insert(record1);
        return insert;
    }



    @Override
    public int deleteRecord(Integer id) {
        int i = recordMapper.deleteById(id);
        return i;
    }


    /**
     * 访客查询
     */
    @Override
    public Page find(Integer pageNum, Integer pageSize, String search) {
        Page page = new Page<>(pageNum, pageSize);
        QueryWrapper<Record> qw = new QueryWrapper<>();
        qw.like("student_name", search);
        Page visitorPage = recordMapper.selectPage(page, qw);
        return visitorPage;
    }

}
