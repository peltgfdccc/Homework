package com.example.springboot.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Record;
import com.example.springboot.entity.Repair;

public interface RecordMapper  extends BaseMapper<Record> {


}
