package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.DormBuild;


public interface DormBuildMapper extends BaseMapper<DormBuild> {

}
